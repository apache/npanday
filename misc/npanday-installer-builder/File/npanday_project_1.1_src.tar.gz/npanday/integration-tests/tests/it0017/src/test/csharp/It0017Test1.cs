namespace org.apache.maven.it.unit {
	using NUnit.Framework;
	using System;
	using org.apache.maven.it;

	[TestFixture]
	public class It0017Test1  {
		private String hello = "hello";

		[Test]
		public void TestSample() {
			new It0016();
		}
		
	}

}