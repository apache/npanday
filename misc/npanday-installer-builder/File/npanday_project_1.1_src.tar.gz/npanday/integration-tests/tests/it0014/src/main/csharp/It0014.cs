namespace org.apache.maven.it {

public class It0012 {

	public static void Main () { 
		new It0012();
		new It0013();
		System.Console.Write("Hello World!");
	} 
}
}
