namespace org.apache.maven.it {

public class It0019 {
	public static void Main () { 
		System.Console.Write("Hello World!"); 
	} 
}
}
