Imports org.apache.maven.it
NameSpace org.apache.maven.it
Public Class It0021
	Public Sub New()
       
	End Sub
End Class
End NameSpace
