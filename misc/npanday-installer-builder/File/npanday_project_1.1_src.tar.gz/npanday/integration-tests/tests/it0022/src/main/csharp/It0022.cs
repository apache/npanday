namespace org.apache.maven.it {

public class It0022 {
	public static void Main () { 
		System.Console.Write("Hello World!"); 
	} 
}
}
