namespace org.apache.maven.it {

using System;

public class It0003 {

	public static void Main () { 
		System.Console.Write("Hello World!");
		new It0002();
	}

	public String GetValue()
	{
	    return "test";
    }
}
}
