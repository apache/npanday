Imports org.apache.maven.it.It0001
NameSpace org.apache.maven.it
Public Class HelloWorld
	Public Sub New()
       
	End Sub
End Class
End NameSpace
