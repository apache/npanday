namespace org.apache.maven.it {

public class It0028 {
	public static void Main () { 
		System.Console.Write("Hello World!"); 
		It0026 it = new It0026();
	} 
}
}
