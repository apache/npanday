using System;
using System.Collections.Generic;
using System.Text;

namespace SAClassLibrary
{
    public class Items
    {
        public void alert(string a)
        {
            Console.WriteLine(a);
        }
    }
}
