using System;
using System.IO;

namespace Sample
{
    public class MyApp
    {
        public MyApp()
        {
            Console.WriteLine("Hello");
        }
    }
}
