using System;
using NUnit.Framework;

namespace Sample
{

	[TestFixture]
	public class MyAppTest
	{

		[SetUp]
		protected void SetUp()
		{
		}

		[Test]
		public void TestSample()
		{

		}
	}
}

