Imports System
Imports NUnit.Framework

Namespace MyAppTest
    <TestFixture()> _
    Public Class MyAppTest
        <Test()> _
        Sub Main()
            Assert.IsTrue(True)
        End Sub
    End Class
End Namespace
