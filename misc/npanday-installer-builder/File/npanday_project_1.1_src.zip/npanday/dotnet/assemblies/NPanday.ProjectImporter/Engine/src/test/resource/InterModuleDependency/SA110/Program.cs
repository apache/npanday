using System;
using System.Collections.Generic;
using System.Text;
using SAClassLibrary;

namespace SA110
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Items i = new Items();
            i.alert("Hello");
         
        }
    }
}
