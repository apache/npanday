Module Module1

    Sub Main()
        Console.WriteLine("hello")
    End Sub

End Module
