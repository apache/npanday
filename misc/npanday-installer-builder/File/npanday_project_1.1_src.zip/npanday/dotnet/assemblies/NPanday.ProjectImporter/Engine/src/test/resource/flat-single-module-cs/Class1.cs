using System;
using System.Collections.Generic;
using System.Text;

namespace FlatSingleModule
{
    public class Class1
    {
        // Victims of Love by Joe Lamont
    }
}
