Imports Microsoft.VisualBasic

Public Class Class1
    Public Function CurrentDay()
        Return System.DateTime.Today
    End Function
End Class
