namespace org.apache.maven.it {

public class It0030 {
    public static void Main () { 
            new It0028();
            new It0029();
            System.Console.Write("Hello World!"); 
    } 
}
}
