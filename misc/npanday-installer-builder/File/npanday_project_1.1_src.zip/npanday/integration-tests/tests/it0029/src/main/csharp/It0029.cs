namespace org.apache.maven.it {

public class It0029 {
    public static void Main () { 
            System.Console.Write("Hello World!"); 
    } 
}
}
