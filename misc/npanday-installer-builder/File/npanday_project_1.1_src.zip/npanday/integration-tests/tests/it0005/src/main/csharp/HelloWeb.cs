namespace org.apache.maven.it {

public class HelloWeb {
	public static void Main () { 
		System.Console.Write("Hello World!");
		 new It0002();
		 new It0003();
	} 
}
}
