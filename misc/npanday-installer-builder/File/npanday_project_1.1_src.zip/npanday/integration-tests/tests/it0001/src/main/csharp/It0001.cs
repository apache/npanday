namespace NPanday.IT {

public class It0001 {
	public static void Main () { 
		System.Console.Write("Hello World!"); 
	} 
}
}
