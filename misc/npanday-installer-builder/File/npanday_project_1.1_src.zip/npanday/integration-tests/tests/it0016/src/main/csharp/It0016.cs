namespace org.apache.maven.it {

public class It0016 {

	public static void Main () { 
		new It0015();
		System.Console.Write("Hello World!");
	} 
}
}
